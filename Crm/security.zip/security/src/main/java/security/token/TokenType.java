package security.token;

public enum TokenType {
  BEARER
}
